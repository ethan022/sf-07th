﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace _0818_2.Models
{
    // 계산 기능을 담당하는 Model 클래스
    // UI와 완전히 독립적인 순수한 계산 로직만 포함
    class Calculator
    {
        #region 기본 수학 연산들

        /// <summary>
        /// 두 수를 더한다.              
        /// </summary>
        /// <param name="x">첫 번째 수</param>
        /// <param name="y">두 번째 수</param>
        /// <returns>더한 결과</returns>

        public double Add(double x, double y)
        {
            return x + y;
        }

        /// <summary>
        /// 첫 번째 수에서 두 번째 수를 뺍니다.           
        /// </summary>
        /// <param name="x">첫 번째 수</param>
        /// <param name="y">두 번째 수</param>
        /// <returns>뺀 결과</returns>
        public double Subtract(double x, double y)
        {
            return x - y;
        }

        /// <summary>
        /// 두 수를 곱합니다.
        /// </summary>
        /// <param name="x">첫 번째 수</param>
        /// <param name="y">두 번째 수</param>
        /// <returns>곱한 결과</returns>
        public double Multiply(double x, double y)
        {
            return x * y;
        }

        /// <summary>
        /// 첫 번째 수에서 두 번째 수를 나눕니다.         
        /// </summary>
        /// <param name="x">첫 번째 수</param>
        /// <param name="y">두 번째 수</param>
        /// <returns>나눈 결과</returns>
        public double Divide(double x, double y)
        {
            if (y == 0)
            {
                throw new DivideByZeroException("0으로 나눌 수 없습니다.");
            }
            return x / y;
        }

        #endregion


        /// <summary>
        /// 문자열이 유효한 숫자인지 확인합니다.       
        /// </summary>
        /// <param name="input">첫 번째 수</param>
        /// <returns>유효한 숫자면 True, 아니면 False</returns>
        public bool IsValidNumber(string input)
        {
            // double.TryParse는 반환 성공 시 True, 실패 시 False 반환
            return double.TryParse(input, out var _);
        }

        /// <summary>
        /// 문자열을 안전하게 숫자로 변환합니다.    
        /// </summary>
        /// <param name="input">첫 번째 수</param>
        /// <returns>변환된 숫자 (반환 실패시 0)</returns>
        public double ParseNumber(string input)
        {
            if (double.TryParse(input, out var result))
            {
                return result;
            }
            return 0;
        }

        public double Calculate(double x, double y, string operation)
        {
            return operation switch
            {
                "+" => Add(x, y),
                "-" => Subtract(x, y),
                "*" => Multiply(x, y),
                "/" => Divide(x, y),
                _ => throw new AggregateException($"지원하지 않는 연산자 입니다."),
            };
        }
    }
}
