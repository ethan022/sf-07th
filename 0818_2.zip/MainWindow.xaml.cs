﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _0818_2.ViewModels;

namespace _0818_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // View와 ViewModel 연결
            this.DataContext = new CalculatorViewModel();
        }

        // code-behind패턴
        // 하나의 메서드가 너무 많은 책임을 가지고 있다.
        // UI와 로직이 강하게 결합
        // 코드 수정 시 다른 부분에 영향을 줄 수 있다...
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double num1 = double.Parse(txtFirst.Text);
            double num2 = double.Parse(txtScond.Text);

            string op = (sender as System.Windows.Controls.Button).Content.ToString();
            double result = 0;

            // 계산 로직
            switch (op) {
                case "+": result  = num1 + num2; break;
                case "-": result  = num1 - num2; break;
                case "*": result  = num1 * num2; break;
                case "/": result = num2 != 0 ? num1 / num2 : 0; ; break;
            }

            txtResult.Text = result.ToString();
        }
    }
}