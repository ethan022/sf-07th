﻿using _0818_2.Commands;
using _0818_2.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace _0818_2.ViewModels
{
    class CalculatorViewModel : BaseViewModel
    {
        private readonly Calculator _calculator = new Calculator();

        private string _firstNumber;
        private string _secondNumber;
        private string _resultNumber;

        // 사용자가 TextBox에 입력 -> ViewModel의 FirstNumber 속성 변경
        // ViewModel에서 Result 속성 변경 -> UI의 TextBox 값은 업데이트 X

        // WPF는 ViewModel의 속성이 언제 바뀐지 모름
        // 속성이 바뀌었다.는 알림이 없으면 UI를 업데이트 하지 않음

        // INotifyPropertyChanged
        // ViewModel 속성 변경 -> PropertyChaged 이벤트 발생
        // -> WPF 바인딩 엔진이 이벤트 감지 -> 해당 속성의 새 값을 가져와서 UI 변경

        public event PropertyChangedEventHandler? PropertyChanged;


        public string FirstNumber
        {
            get { return _firstNumber; }
            set => SetProperty(ref _firstNumber, value, ()=>
            {
                // 값이 실제로 변경되었을 때 만 실행되는 추가 작업
                CommandManager.InvalidateRequerySuggested();    
            }); 
            //{ 
            //    _firstNumber = value;
            //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("FirstNumber"));
            //}
        }

        public string SecondNumber
        {
            get { return _secondNumber; }
            set => SetProperty(ref _secondNumber, value, () =>
            {
                // 값이 실제로 변경되었을 때 만 실행되는 추가 작업
                CommandManager.InvalidateRequerySuggested();
            }); 
            //{ 
            //    _secondNumber = value;
            //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("SecondNumber"));
            //}
        }

        public string ResultNumber
        {
            get { return _resultNumber; }
            set => SetProperty(ref _resultNumber, value);
            //{ 
            //    _resultNumber = value;
            //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("ResultNumber"));
            //}
        }

        // Commands - 각 버튼에 연결될 명령들
        public ICommand AddCommand { get; }
        public ICommand SubtractCommand { get; }
        public ICommand MultiplyCommand { get; }
        public ICommand DivideCommand { get; }
        public ICommand ClearCommand { get; }

        public CalculatorViewModel()
        {
            AddCommand = new RelayCommand(
                execute => Calculate("+"), // 실행할 메서드
                canExecute: _ => CanCalculate() // 실행 가능 조건
            );

            SubtractCommand = new RelayCommand(
                execute => Calculate("-"), // 실행할 메서드
                canExecute: _ => CanCalculate() // 실행 가능 조건
            );

            MultiplyCommand = new RelayCommand(
               execute => Calculate("*"), // 실행할 메서드
               canExecute: _ => CanCalculate() // 실행 가능 조건
            );

            DivideCommand = new RelayCommand(
               execute => Calculate("/"), // 실행할 메서드
               canExecute: _ => CanCalculate() // 실행 가능 조건
            );
            ClearCommand = new RelayCommand(
               execute: _ => Clear() // 실행할 메서드
               //canExecute: _ => CanCalculate() // 실행 가능 조건
            );
        }

        // 첫 번째 숫자와 두 번째 숫자가 올바른 값인지 확인
        private bool CanCalculate()
        {
            return _calculator.IsValidNumber(_firstNumber) &&
                _calculator.IsValidNumber(_secondNumber);
        }

        private void Calculate(string operation)
        {
            try
            {
                double num1 = _calculator.ParseNumber(_firstNumber);
                double num2 = _calculator.ParseNumber(_secondNumber);

                double result = _calculator.Calculate(num1, num2, operation);
                ResultNumber = $"{num1} {operation} {num2} = {result}";
            }
            catch (Exception ex) 
            {
                ResultNumber = $"오류 : {ex.Message}";
            }
        }

        private void Clear()
        {
            FirstNumber = "";
            SecondNumber = "";
            ResultNumber = "";
        }
    }
}
