﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace _0818_2.ViewModels
{
    public abstract class BaseViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// 속성이 변경될 때 발생하는 이벤트
        /// WPF 바인딩 엔진이 이 이벤트를 구독하여 UI를 자동으로 업데이트
        /// </summary>
        public event PropertyChangedEventHandler? PropertyChanged;

        /// <summary>
        /// 속성 변경 알림을 보내는 기본 메서드
        /// </summary> 
        /// <param name="propertyName">변경된 속성의 이름 (자동으로 채워짐)</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            // PropertyChanged 이벤트가 구독되어 있으면 발생시킴
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// 속성 값을 설정하고 필요시 변경 알림을 보내는 헬퍼 메서드
        /// BasicViewModel 핵심 기능!
        /// </summary> 
        /// <typeparam name="T">속성의 타입</typeparam>
        /// <param name="field">값을 저장할 private 필드 (ref로 전달)</param>
        /// <param name="value">새로 설정할 값</param>
        /// <param name="propertyName">속성 이름 (자동으로 채워짐)</param>
        /// <returns>값이 실제로 변경되었으면 True, 아니면 False</returns>
        protected virtual bool SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            // 1단계: 값이 실제로 바뀌었는지 확인 (성능 최적화)
            if (Equals(field, value)) 
            {
                // 같은 값이면 아무것도 안하겠다.
                return false; 
            }

            // 2단계: 새 값으로 설정
            field = value;

            // 3단계 : 변경 알림 발생
            OnPropertyChanged(propertyName);

            // 4단계: 변경되었음을 알려줌
            return true;
        }


        /// <summary>
        /// 속성 값을 설정하고 추가 작업을 수행하는 헬퍼 메서드
        /// 값이 변경되었을 때만 추가 작업이 실행됨
        /// </summary> 
        /// <typeparam name="T">속성의 타입</typeparam>
        /// <param name="field">값을 저장할 private 필드 (ref로 전달)</param>
        /// <param name="value">새로 설정할 값</param>
        /// <param name="onChaged">값이 변경되었을 때 실행할 추가 작업</param>
        /// <param name="propertyName">속성 이름 (자동으로 채워짐)</param>
        /// <returns>값이 실제로 변경되었으면 True, 아니면 False</returns>
        /// 
        protected virtual bool SetProperty<T>(ref T field, T value, 
            System.Action onChaged,  [CallerMemberName] string propertyName = null)
        {
            if (SetProperty(ref field, value, propertyName))
            {
                onChaged?.Invoke();
                return true;
            }
            return false;   
        }
    }
}
